from django.contrib import admin
from .models import apartment

admin.site.register(apartment)
